import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";

export default function Success() {
  const [, setLocation] = useLocation();
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    // Countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setLocation("/login");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/10 p-4">
      <Card className="w-full max-w-md shadow-2xl border-primary/10">
        <CardContent className="pt-12 pb-12">
          <div className="flex flex-col items-center justify-center space-y-6 text-center">
            <div className="relative">
              <CheckCircle2 className="h-24 w-24 text-primary animate-bounce-in" />
              <div className="absolute inset-0 h-24 w-24 rounded-full bg-primary/20 animate-ping" />
            </div>
            
            <div className="space-y-2">
              <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Login Realizado!
              </h1>
              <p className="text-muted-foreground text-lg">
                Você será redirecionado em
              </p>
            </div>

            <div className="relative">
              <div className="text-6xl font-bold text-primary tabular-nums">
                {countdown}
              </div>
              <div className="absolute -inset-4 rounded-full border-4 border-primary/20 animate-pulse" />
            </div>

            <p className="text-sm text-muted-foreground">
              Redirecionando para a tela de login...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
