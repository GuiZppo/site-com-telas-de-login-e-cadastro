import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { getUserByEmail } from "./db";

function createMockContext(): TrpcContext {
  const cookies: Record<string, { value: string; options: Record<string, unknown> }> = {};

  const ctx: TrpcContext = {
    user: undefined,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      cookie: (name: string, value: string, options: Record<string, unknown>) => {
        cookies[name] = { value, options };
      },
      clearCookie: (name: string, options: Record<string, unknown>) => {
        delete cookies[name];
      },
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("localAuth.register", () => {
  it("should register a new user successfully", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueEmail = `test${Date.now()}@example.com`;

    const result = await caller.localAuth.register({
      name: "Test User",
      age: 25,
      email: uniqueEmail,
      password: "password123",
    });

    expect(result.success).toBe(true);
    expect(result.message).toBe("Usuário cadastrado com sucesso");

    // Verify user was created in database
    const user = await getUserByEmail(uniqueEmail);
    expect(user).toBeDefined();
    expect(user?.name).toBe("Test User");
    expect(user?.age).toBe(25);
    expect(user?.email).toBe(uniqueEmail);
    expect(user?.password).toBeDefined();
    expect(user?.password).not.toBe("password123"); // Password should be hashed
  });

  it("should fail when registering with duplicate email", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const uniqueEmail = `duplicate${Date.now()}@example.com`;

    // Register first user
    await caller.localAuth.register({
      name: "First User",
      age: 30,
      email: uniqueEmail,
      password: "password123",
    });

    // Try to register with same email
    await expect(
      caller.localAuth.register({
        name: "Second User",
        age: 25,
        email: uniqueEmail,
        password: "password456",
      })
    ).rejects.toThrow("Email já cadastrado");
  });

  it("should validate input data", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    // Test invalid email
    await expect(
      caller.localAuth.register({
        name: "Test",
        age: 25,
        email: "invalid-email",
        password: "password123",
      })
    ).rejects.toThrow();

    // Test short password
    await expect(
      caller.localAuth.register({
        name: "Test",
        age: 25,
        email: "test@example.com",
        password: "123",
      })
    ).rejects.toThrow();

    // Test invalid age
    await expect(
      caller.localAuth.register({
        name: "Test",
        age: 0,
        email: "test@example.com",
        password: "password123",
      })
    ).rejects.toThrow();
  });
});

describe("localAuth.login", () => {
  beforeEach(async () => {
    // Create a test user before each login test
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);
    
    const testEmail = "logintest@example.com";
    const existingUser = await getUserByEmail(testEmail);
    
    if (!existingUser) {
      await caller.localAuth.register({
        name: "Login Test User",
        age: 28,
        email: testEmail,
        password: "testpassword",
      });
    }
  });

  it("should login successfully with correct credentials", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.localAuth.login({
      email: "logintest@example.com",
      password: "testpassword",
    });

    expect(result.success).toBe(true);
    expect(result.message).toBe("Login realizado com sucesso");
    expect(result.user).toBeDefined();
    expect(result.user.email).toBe("logintest@example.com");
    expect(result.user.name).toBe("Login Test User");
  });

  it("should fail with incorrect password", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.localAuth.login({
        email: "logintest@example.com",
        password: "wrongpassword",
      })
    ).rejects.toThrow("Email ou senha incorretos");
  });

  it("should fail with non-existent email", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.localAuth.login({
        email: "nonexistent@example.com",
        password: "password123",
      })
    ).rejects.toThrow("Email ou senha incorretos");
  });
});
