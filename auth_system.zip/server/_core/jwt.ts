import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./env";

const SECRET_KEY = new TextEncoder().encode(ENV.cookieSecret);
const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export async function signJWT(payload: { userId: number }): Promise<string> {
  const issuedAt = Date.now();
  const expirationSeconds = Math.floor((issuedAt + ONE_WEEK_MS) / 1000);

  return new SignJWT({ userId: payload.userId })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(SECRET_KEY);
}

export async function verifyJWT(token: string): Promise<{ userId: number } | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET_KEY);
    return payload as { userId: number };
  } catch (error) {
    return null;
  }
}
